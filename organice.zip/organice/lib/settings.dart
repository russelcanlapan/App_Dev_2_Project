import 'package:flutter/material.dart';
import 'assignments.dart';
import 'calendar.dart';
import 'main.dart';

void main() {
  runApp(SettingsPage());
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: Settings());
  }
}

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  // insert code here

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text('Settings'),
          backgroundColor: Colors.blue.shade700,
        ),
      drawer: const NavigationDrawer(),

    );
  }
}

class NavigationDrawerDemo extends StatefulWidget {
  const NavigationDrawerDemo({super.key});

  @override
  State<NavigationDrawerDemo> createState() => _NavigationDrawerDemoState();
}

class _NavigationDrawerDemoState extends State<NavigationDrawerDemo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings', style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.blue.shade700,
      ),
      drawer: const NavigationDrawer(),
    );
  }
}

class NavigationDrawer extends StatelessWidget {
  const NavigationDrawer({super.key});

  @override
  Widget build(BuildContext context) => Drawer(
    child: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[buildHeader(context), buildMenuItems(context)],
      ),
    ),
  );

  Widget buildHeader(BuildContext context) => Container(
    padding: EdgeInsets.only(top: 25, bottom: 25),
    color: Colors.blue.shade700,
    child: Column(
      children: const [
        Text('Ben Dover', style: TextStyle(fontSize: 28, color: Colors.white)),
        Text('bendover@hotmail.com', style: TextStyle(fontSize: 16, color: Colors.white))
      ],
    ),
  );

  Widget buildMenuItems(BuildContext context) => Wrap(
    runSpacing: 8, // vertical spacing
    children: [
      ListTile(
        leading: const Icon(Icons.home_outlined),
        title: const Text('Assignments'),
        onTap: () {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const Assignments()));
        },
      ),
      ListTile(
        leading: const Icon(Icons.calendar_today_outlined),
        title: const Text('Calendar'),
        onTap: () {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const Calendar()));
        },
      ),
      const Divider(color: Colors.black54),

      ListTile(
        leading: const Icon(Icons.settings_outlined),
        title: const Text('Settings'),
        onTap: () {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const Settings()));
        },
      ),
      ListTile(
        leading: const Icon(Icons.logout, color: Colors.red,),
        title: const Text('Logout', style: TextStyle(color: Colors.red)),
        onTap: () {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const LoginPage()));
        },
      ),
    ],
  );
}

