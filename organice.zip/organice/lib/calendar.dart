import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'assignments.dart';
import 'settings.dart';
import 'main.dart';

void main() {
  runApp(CalendarPage());
}

class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Calendar(),
    );
  }
}

class Calendar extends StatefulWidget {
  const Calendar({super.key});

  @override
  State<Calendar> createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> {

  DateTime today = DateTime.now();

  void _onDaySelected(DateTime day, DateTime focusedDay) {
    setState(() {
      today = day;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calendar', style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.blue.shade700,
      ),
      drawer: const NavigationDrawer(),
      body: content(),
    );
  }

  Widget content() {
    return Padding(
      padding: EdgeInsets.all(50),
      child: Column(
        children: [
          Container(
            child: TableCalendar(
              locale: 'en_US',
              headerStyle: HeaderStyle(
                  formatButtonVisible: false, titleCentered: true, titleTextStyle: TextStyle(fontSize: 26)),
              availableGestures: AvailableGestures.all,
              selectedDayPredicate: (day) => isSameDay(day, today),
              focusedDay: today,
              firstDay: DateTime.now(),
              lastDay: DateTime(DateTime
                  .now()
                  .year + 5,
                  DateTime
                      .now()
                      .month),
              onDaySelected: _onDaySelected,
              calendarStyle: CalendarStyle(
                  defaultTextStyle: TextStyle(fontSize: 20),
                selectedTextStyle: TextStyle(fontSize: 20, color: Colors.white),
                disabledTextStyle: TextStyle(fontSize: 20, color: Colors.grey.shade500),
                outsideTextStyle: TextStyle(fontSize: 20, color: Colors.grey.shade500),
                weekendTextStyle:  TextStyle(fontSize: 20),
                selectedDecoration: BoxDecoration(color: Colors.red),
                defaultDecoration: BoxDecoration(color: Colors.grey.shade400),
                weekendDecoration: BoxDecoration(color: Colors.grey.shade400),
                todayDecoration: BoxDecoration(color: Colors.red.shade300),
              ),
            ),
          ),
          SizedBox(height: 50,),
          Text('Selected Day = ' + today.toString().split(" ")[0], style: TextStyle(fontSize: 20),)
        ],
      ));

  }

}


class NavigationDrawer extends StatelessWidget {
  const NavigationDrawer({super.key});

  @override
  Widget build(BuildContext context) =>
      Drawer(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[buildHeader(context), buildMenuItems(context)],
          ),
        ),
      );

  Widget buildHeader(BuildContext context) =>
      Container(
        padding: EdgeInsets.only(top: 25, bottom: 25),
        color: Colors.blue.shade700,
        child: Column(
          children: const [
            Text('Ben Dover',
                style: TextStyle(fontSize: 28, color: Colors.white)),
            Text('bendover@hotmail.com',
                style: TextStyle(fontSize: 16, color: Colors.white))
          ],
        ),
      );

  Widget buildMenuItems(BuildContext context) =>
      Wrap(
        runSpacing: 8, // vertical spacing
        children: [
          ListTile(
            leading: const Icon(Icons.home_outlined),
            title: const Text('Assignments'),
            onTap: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => const Assignments()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.calendar_today_outlined),
            title: const Text('Calendar'),
            onTap: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => const Calendar()));
            },
          ),
          const Divider(color: Colors.black54),

          ListTile(
            leading: const Icon(Icons.settings_outlined),
            title: const Text('Settings'),
            onTap: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => const Settings()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red,),
            title: const Text('Logout', style: TextStyle(color: Colors.red)),
            onTap: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => const LoginPage()));
            },
          ),
        ],
      );
}